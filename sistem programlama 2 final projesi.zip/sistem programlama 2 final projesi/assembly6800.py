import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, simpledialog, ttk
import time
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from collections import defaultdict

# 6800 KOMUTLARI - opcode, mode, length
INSTRUCTIONS = {
    "LDAA": [0x86, 'immediate', 2],
    "LDAB": [0xC6, 'immediate', 2],
    "STAA": [0x97, 'direct', 2],
    "STAB": [0xD7, 'direct', 2],
    "INCA": [0x4C, 'inherent', 1],
    "DECA": [0x4A, 'inherent', 1],
    "INCB": [0x5C, 'inherent', 1],
    "DECB": [0x5A, 'inherent', 1],
    "ADDA": [0x8B, 'immediate', 2],
    "ADDB": [0xCB, 'immediate', 2],
    "SUBA": [0x80, 'immediate', 2],
    "SUBB": [0xC0, 'immediate', 2],
    "JMP":  [0x7E, 'extended', 3],
    "JSR":  [0xBD, 'extended', 3],
    "RTS":  [0x39, 'inherent', 1],
    "BNE":  [0x26, 'relative', 2],
    "BEQ":  [0x27, 'relative', 2],
    "BRA":  [0x20, 'relative', 2],
    "CLR":  [0x4F, 'inherent', 1],
    "CLC":  [0x0C, 'inherent', 1],
    "SEC":  [0x0D, 'inherent', 1],
    "CLV":  [0x0A, 'inherent', 1],
    "SEV":  [0x0B, 'inherent', 1],
    "NOP":  [0x01, 'inherent', 1],
    "TAB":  [0x16, 'inherent', 1],
    "TBA":  [0x17, 'inherent', 1],
    "LDAA_IDX": [0xA6, 'indexed', 2],
    "STAA_IDX": [0xA7, 'indexed', 2],
    "LDX":   [0xCE, 'immediate16', 3],
    "INX":   [0x08, 'inherent', 1],
    "DEX":   [0x09, 'inherent', 1],
    "ANDA": [0x84, 'immediate', 2],
    "ANDB": [0xC4, 'immediate', 2],
    "ORA":  [0x8A, 'immediate', 2],
    "ORB":  [0xCA, 'immediate', 2],
    "EORA": [0x88, 'immediate', 2],
    "EORB": [0xC8, 'immediate', 2],
    "CMPA": [0x81, 'immediate', 2],
    "CMPB": [0xC1, 'immediate', 2],
    "SEI":  [0x0E, 'inherent', 1],  # Kesmeleri devre dışı bırak
    "CLI":  [0x0F, 'inherent', 1],  # Kesmeleri etkinleştir
    "RTI":  [0x3B, 'inherent', 1],  # Kesmeden dön
}

def parse_number(s):
    s = s.strip()
    # Önce decimal mi bak
    if s.isdigit() or (s[0] == '-' and s[1:].isdigit()):
        return int(s)
    # Hex için başında $ veya 0x veya sadece hex karakterleri ise
    if s.startswith('$'):
        return int(s[1:], 16)
    if s.startswith('0x'):
        return int(s, 16)
    if s.startswith('%'):
        return int(s[1:], 2)
    # Sadece hex karakterlerinden oluşuyorsa, hex kabul et (ör: 80FF gibi)
    if all(c in '0123456789ABCDEFabcdef' for c in s):
        return int(s, 16)
    raise ValueError("Sayı formatı hatalı: " + s)


def to_hex(n, width=2):
    return f"{n:0{width}X}"

class Assembler6800:
    def __init__(self):
        self.symbol_table = {}
        self.machine_code = []
        self.translation_table = []
        self.origin = 0x8000
        self.pc_to_line = {}

    def assemble(self, code: str):
        self.symbol_table = {}
        self.machine_code = []
        self.translation_table = []
        self.origin = 0x8000
        self.pc_to_line = {}
        location_counter = self.origin
        code_lines = [line.rstrip() for line in code.splitlines()]
        # Pass 1: Label adresleri
        for i, line in enumerate(code_lines):
            clean = line.strip()
            if not clean or clean.startswith(';'):
                continue
            label = ""
            if ':' in clean:
                label, clean = clean.split(':', 1)
                label = label.strip()
                clean = clean.strip()
                if label:
                    self.symbol_table[label.upper()] = location_counter
            if not clean:
                continue
            parts = clean.split()
            inst = parts[0].upper()
            if inst == "ORG":
                location_counter = parse_number(parts[1])
                if i == 0:
                    self.origin = location_counter
            elif inst == "END":
                break
            elif inst in INSTRUCTIONS:
                length = INSTRUCTIONS[inst][2]
                location_counter += length
        # Pass 2: Kod üretimi
        location_counter = self.origin
        for i, line in enumerate(code_lines):
            line_content = line.strip()
            if not line_content or line_content.startswith(';'):
                self.translation_table.append((line, '', ''))
                continue
            label = ""
            if ':' in line_content:
                label, rest = line_content.split(':', 1)
                label = label.strip()
                line_content = rest.strip()
            if not line_content:
                self.translation_table.append((line, to_hex(location_counter, 4), ''))
                continue
            parts = line_content.split(None, 1)
            inst = parts[0].upper()
            operand = parts[1].strip() if len(parts) > 1 else None
            # Yorum silici
            if operand:
                operand = operand.split(';')[0].strip()
            if inst == "ORG":
                location_counter = parse_number(operand)
                self.translation_table.append((line, to_hex(location_counter, 4), ''))
                continue
            if inst == "END":
                self.translation_table.append((line, '', ''))
                break
            if inst not in INSTRUCTIONS:
                self.translation_table.append((line, to_hex(location_counter, 4), 'HATALI KOMUT!'))
                continue
            opcode, mode, length = INSTRUCTIONS[inst]
            code_bytes = []
            try:
                if mode == "immediate":
                    code_bytes.append(opcode)
                    val = parse_number(operand.replace('#', ''))
                    code_bytes.append(val & 0xFF)
                elif mode == "direct":
                    code_bytes.append(opcode)
                    if operand.upper() in self.symbol_table:
                        addr = self.symbol_table[operand.upper()]
                    else:
                        addr = parse_number(operand)
                    code_bytes.append(addr & 0xFF)
                elif mode == "extended":
                    code_bytes.append(opcode)
                    if operand.upper() in self.symbol_table:
                        addr = self.symbol_table[operand.upper()]
                    else:
                        addr = parse_number(operand)
                    code_bytes.append((addr >> 8) & 0xFF)
                    code_bytes.append(addr & 0xFF)
                elif mode == "inherent":
                    code_bytes.append(opcode)
                elif mode == "relative":
                    code_bytes.append(opcode)
                    if operand.upper() in self.symbol_table:
                        target_addr = self.symbol_table[operand.upper()]
                        offset = target_addr - (location_counter + 2)
                    else:
                        offset = parse_number(operand)
                    if not -128 <= offset <= 127:
                        self.translation_table.append((line, to_hex(location_counter, 4), 'Offset çok büyük!'))
                        continue
                    code_bytes.append(offset & 0xFF)
                elif mode == "indexed":
                    code_bytes.append(opcode)
                    base, _ = operand.split(',')
                    val = parse_number(base)
                    code_bytes.append(val & 0xFF)
                elif mode == "immediate16":
                    code_bytes.append(opcode)
                    val = parse_number(operand.replace('#', ''))
                    code_bytes.append((val >> 8) & 0xFF)
                    code_bytes.append(val & 0xFF)
                else:
                    self.translation_table.append((line, to_hex(location_counter, 4), 'Desteklenmeyen mod!'))
                    continue
            except Exception as e:
                self.translation_table.append((line, to_hex(location_counter, 4), f'Hata: {str(e)}'))
                continue
            self.machine_code.append((location_counter, code_bytes, line))
            hex_code = ' '.join(to_hex(b) for b in code_bytes)
            self.translation_table.append((line, to_hex(location_counter, 4), hex_code))
            self.pc_to_line[location_counter] = i + 1
            location_counter += len(code_bytes)
        return self.machine_code, self.translation_table, self.origin

class Simulator6800:
    def __init__(self):
        self.reset()
        self.irq_vector = 0xFFF8
        self.nmi_vector = 0xFFFC
        self.stats = defaultdict(int)
        self.last_execution_time = 0
        self.irq_pending = False
        self.nmi_pending = False

    def reset(self):
        self.memory = [0x00] * 0x10000
        self.A = 0
        self.B = 0
        self.X = 0
        self.PC = 0x8000
        self.SP = 0xFFFF
        self.flags = {'Z':0, 'N':0, 'C':0, 'V':0, 'I':1}  # I=1: Kesmeler devre dışı
        self.last_instruction = ""
        self.last_effect = ""
        self.step_count = 0
        self.cycle_count = 0
        self.start_time = time.time()
        self.irq_pending = False
        self.nmi_pending = False
        self.stats = defaultdict(int)
        self.last_execution_time = 0

    def load_code(self, code_blocks, start_addr):
        for addr, bytes_list, _ in code_blocks:
            for i, b in enumerate(bytes_list):
                self.memory[addr + i] = b
        self.PC = start_addr
        
        # Varsayılan kesme vektörlerini ayarla
        self.set_vector(self.irq_vector, 0x8000)
        self.set_vector(self.nmi_vector, 0x8000)

    def set_vector(self, address, value):
        self.memory[address] = (value >> 8) & 0xFF
        self.memory[address+1] = value & 0xFF

    def flag_update_NZ(self, value):
        self.flags['Z'] = int((value & 0xFF) == 0)
        self.flags['N'] = int((value & 0x80) != 0)

    def flag_update_ADC(self, result):
        self.flags['C'] = int(result > 0xFF or result < 0)

    def handle_interrupts(self):
        if self.nmi_pending:
            self.nmi_pending = False
            return self.trigger_nmi()
        if self.irq_pending and not self.flags['I']:
            self.irq_pending = False
            return self.trigger_irq()
        return ""

    def trigger_irq(self):
        if self.flags['I'] == 0:  # Kesmeler etkinse
            # PC ve CCR'ı stack'e kaydet
            self.SP = (self.SP - 1) & 0xFFFF
            self.memory[self.SP] = (self.PC >> 8) & 0xFF   # PC high
            self.SP = (self.SP - 1) & 0xFFFF
            self.memory[self.SP] = self.PC & 0xFF          # PC low
            self.SP = (self.SP - 1) & 0xFFFF
            
            # CCR oluştur: I|N|Z|V|C
            ccr = (self.flags['I'] << 4) | (self.flags['N'] << 3) | \
                  (self.flags['Z'] << 2) | (self.flags['V'] << 1) | self.flags['C']
            self.memory[self.SP] = ccr
            
            # I bayrağını set et (kesmeleri devre dışı bırak)
            self.flags['I'] = 1
            
            # IRQ vektöründen yeni PC'yi yükle
            hi = self.memory[self.irq_vector]
            lo = self.memory[self.irq_vector+1]
            self.PC = (hi << 8) | lo
            return "IRQ kesmesi işlendi"
        return "IRQ kesmesi (I=1, pasif)"

    def trigger_nmi(self):
        # PC ve CCR'ı stack'e kaydet
        self.SP = (self.SP - 1) & 0xFFFF
        self.memory[self.SP] = (self.PC >> 8) & 0xFF   # PC high
        self.SP = (self.SP - 1) & 0xFFFF
        self.memory[self.SP] = self.PC & 0xFF          # PC low
        self.SP = (self.SP - 1) & 0xFFFF
        
        # CCR oluştur: I|N|Z|V|C
        ccr = (self.flags['I'] << 4) | (self.flags['N'] << 3) | \
              (self.flags['Z'] << 2) | (self.flags['V'] << 1) | self.flags['C']
        self.memory[self.SP] = ccr
        
        # I bayrağını set et (kesmeleri devre dışı bırak)
        self.flags['I'] = 1
        
        # NMI vektöründen yeni PC'yi yükle
        hi = self.memory[self.nmi_vector]
        lo = self.memory[self.nmi_vector+1]
        self.PC = (hi << 8) | lo
        return "NMI kesmesi işlendi"

    def step(self):
        start_time = time.perf_counter()
        self.step_count += 1
        
        # Kesmeleri kontrol et
        irq_msg = self.handle_interrupts()
        if irq_msg:
            self.last_effect = irq_msg
            self.last_execution_time = time.perf_counter() - start_time
            self.stats['INTERRUPT'] += 1
            return irq_msg

        pc = self.PC
        op = self.memory[pc]
        msg = ""
        cycles = 1  # Varsayılan döngü sayısı
        
        if op == 0x86:  # LDAA #imm
            val = self.memory[pc+1]
            self.A = val
            self.flag_update_NZ(self.A)
            self.PC += 2
            msg = f"LDAA #{to_hex(val)} → A={to_hex(self.A)}"
            cycles = 2
        elif op == 0xC6:  # LDAB #imm
            val = self.memory[pc+1]
            self.B = val
            self.flag_update_NZ(self.B)
            self.PC += 2
            msg = f"LDAB #{to_hex(val)} → B={to_hex(self.B)}"
            cycles = 2
        elif op == 0xA6:  # LDAA $nn,X
            offset = self.memory[pc+1]
            addr = (self.X + offset) & 0xFFFF
            self.A = self.memory[addr]
            self.flag_update_NZ(self.A)
            self.PC += 2
            msg = f"LDAA ${to_hex(offset)},X → A=[{to_hex(addr,4)}]={to_hex(self.A)}"
            cycles = 4
        elif op == 0xA7:  # STAA $nn,X
            offset = self.memory[pc+1]
            addr = (self.X + offset) & 0xFFFF
            self.memory[addr] = self.A
            self.PC += 2
            msg = f"STAA ${to_hex(offset)},X → [{to_hex(addr,4)}]={to_hex(self.A)}"
            cycles = 4
        elif op == 0xCE:  # LDX #imm16
            hi = self.memory[pc+1]
            lo = self.memory[pc+2]
            self.X = (hi << 8) | lo
            self.PC += 3
            msg = f"LDX #{to_hex(self.X,4)}"
            cycles = 3
        elif op == 0x08:  # INX
            self.X = (self.X + 1) & 0xFFFF
            self.PC += 1
            msg = f"INX → X={to_hex(self.X,4)}"
            cycles = 2
        elif op == 0x09:  # DEX
            self.X = (self.X - 1) & 0xFFFF
            self.PC += 1
            msg = f"DEX → X={to_hex(self.X,4)}"
            cycles = 2
        elif op == 0x97:  # STAA dir
            addr = self.memory[pc+1]
            self.memory[addr] = self.A
            self.PC += 2
            msg = f"STAA ${to_hex(addr)} → [${to_hex(addr)}]={to_hex(self.A)}"
            cycles = 3
        elif op == 0xD7:  # STAB dir
            addr = self.memory[pc+1]
            self.memory[addr] = self.B
            self.PC += 2
            msg = f"STAB ${to_hex(addr)} → [${to_hex(addr)}]={to_hex(self.B)}"
            cycles = 3
        elif op == 0x4C:  # INCA
            self.A = (self.A + 1) & 0xFF
            self.flag_update_NZ(self.A)
            self.PC += 1
            msg = f"INCA → A={to_hex(self.A)}"
            cycles = 2
        elif op == 0x5C:  # INCB
            self.B = (self.B + 1) & 0xFF
            self.flag_update_NZ(self.B)
            self.PC += 1
            msg = f"INCB → B={to_hex(self.B)}"
            cycles = 2
        elif op == 0x4A:  # DECA
            self.A = (self.A - 1) & 0xFF
            self.flag_update_NZ(self.A)
            self.PC += 1
            msg = f"DECA → A={to_hex(self.A)}"
            cycles = 2
        elif op == 0x5A:  # DECB
            self.B = (self.B - 1) & 0xFF
            self.flag_update_NZ(self.B)
            self.PC += 1
            msg = f"DECB → B={to_hex(self.B)}"
            cycles = 2
        elif op == 0x8B:  # ADDA #imm
            val = self.memory[pc+1]
            res = self.A + val
            self.flag_update_NZ(res)
            self.flag_update_ADC(res)
            self.A = res & 0xFF
            self.PC += 2
            msg = f"ADDA #{to_hex(val)} → A={to_hex(self.A)}"
            cycles = 2
        elif op == 0xCB:  # ADDB #imm
            val = self.memory[pc+1]
            res = self.B + val
            self.flag_update_NZ(res)
            self.flag_update_ADC(res)
            self.B = res & 0xFF
            self.PC += 2
            msg = f"ADDB #{to_hex(val)} → B={to_hex(self.B)}"
            cycles = 2
        elif op == 0x80:  # SUBA #imm
            val = self.memory[pc+1]
            res = self.A - val
            self.flag_update_NZ(res)
            self.flag_update_ADC(res)
            self.A = res & 0xFF
            self.PC += 2
            msg = f"SUBA #{to_hex(val)} → A={to_hex(self.A)}"
            cycles = 2
        elif op == 0xC0:  # SUBB #imm
            val = self.memory[pc+1]
            res = self.B - val
            self.flag_update_NZ(res)
            self.flag_update_ADC(res)
            self.B = res & 0xFF
            self.PC += 2
            msg = f"SUBB #{to_hex(val)} → B={to_hex(self.B)}"
            cycles = 2
        elif op == 0x7E:  # JMP ext
            hi = self.memory[pc+1]
            lo = self.memory[pc+2]
            addr = (hi << 8) | lo
            self.PC = addr
            msg = f"JMP ${to_hex(addr,4)}"
            cycles = 3
        elif op == 0xBD:  # JSR ext
            hi = self.memory[pc+1]
            lo = self.memory[pc+2]
            addr = (hi << 8) | lo
            self.SP = (self.SP - 2) & 0xFFFF
            self.memory[self.SP] = ((self.PC+3) >> 8) & 0xFF
            self.memory[self.SP+1] = (self.PC+3) & 0xFF
            self.PC = addr
            msg = f"JSR ${to_hex(addr,4)} → SP={to_hex(self.SP,4)}"
            cycles = 6
        elif op == 0x39:  # RTS
            hi = self.memory[self.SP]
            lo = self.memory[self.SP+1]
            self.PC = (hi << 8) | lo
            self.SP = (self.SP + 2) & 0xFFFF
            msg = f"RTS → PC={to_hex(self.PC,4)}"
            cycles = 5
        elif op == 0x26:  # BNE rel
            offset = self.memory[pc+1]
            offset = offset if offset < 0x80 else offset-0x100
            taken = not self.flags['Z']
            if taken:
                self.PC += 2 + offset
                msg = f"BNE {offset:+} (jumped)"
                cycles = 3
            else:
                self.PC += 2
                msg = "BNE (not taken)"
                cycles = 2
        elif op == 0x27:  # BEQ rel
            offset = self.memory[pc+1]
            offset = offset if offset < 0x80 else offset-0x100
            taken = self.flags['Z']
            if taken:
                self.PC += 2 + offset
                msg = f"BEQ {offset:+} (jumped)"
                cycles = 3
            else:
                self.PC += 2
                msg = "BEQ (not taken)"
                cycles = 2
        elif op == 0x20:  # BRA rel
            offset = self.memory[pc+1]
            offset = offset if offset < 0x80 else offset-0x100
            self.PC += 2 + offset
            msg = f"BRA {offset:+}"
            cycles = 3
        elif op == 0x4F:  # CLR (A=0)
            self.A = 0
            self.flag_update_NZ(self.A)
            self.PC += 1
            msg = "CLR → A=0"
            cycles = 2
        elif op == 0x0C:  # CLC (Carry clear)
            self.flags['C'] = 0
            self.PC += 1
            msg = "CLC → C=0"
            cycles = 2
        elif op == 0x0D:  # SEC (Carry set)
            self.flags['C'] = 1
            self.PC += 1
            msg = "SEC → C=1"
            cycles = 2
        elif op == 0x0A:  # CLV (Overflow clear)
            self.flags['V'] = 0
            self.PC += 1
            msg = "CLV → V=0"
            cycles = 2
        elif op == 0x0B:  # SEV (Overflow set)
            self.flags['V'] = 1
            self.PC += 1
            msg = "SEV → V=1"
            cycles = 2
        elif op == 0x01:  # NOP
            self.PC += 1
            msg = "NOP"
            cycles = 2
        elif op == 0x16:  # TAB
            self.B = self.A
            self.flag_update_NZ(self.B)
            self.PC += 1
            msg = f"TAB → B={to_hex(self.B)}"
            cycles = 2
        elif op == 0x17:  # TBA
            self.A = self.B
            self.flag_update_NZ(self.A)
            self.PC += 1
            msg = f"TBA → A={to_hex(self.A)}"
            cycles = 2
        elif op == 0x81:  # CMPA #imm
            val = self.memory[pc+1]
            res = (self.A - val) & 0xFF
            self.flag_update_NZ(res)
            self.PC += 2
            msg = f"CMPA #{to_hex(val)} → Z={self.flags['Z']}"
            cycles = 2
        elif op == 0x96:  # LDAA dir
            addr = self.memory[pc+1]
            self.A = self.memory[addr]
            self.flag_update_NZ(self.A)
            self.PC += 2
            msg = f"LDAA ${to_hex(addr)} → A={to_hex(self.A)}"
            cycles = 3
        elif op == 0x84:  # ANDA #imm
            val = self.memory[pc+1]
            self.A &= val
            self.flag_update_NZ(self.A)
            self.PC += 2
            msg = f"ANDA #{to_hex(val)} → A={to_hex(self.A)}"
            cycles = 2
        elif op == 0x8A:  # ORA #imm
            val = self.memory[pc+1]
            self.A |= val
            self.flag_update_NZ(self.A)
            self.PC += 2
            msg = f"ORA #{to_hex(val)} → A={to_hex(self.A)}"
            cycles = 2
        elif op == 0x0E:  # SEI (Set Interrupt Mask)
            self.flags['I'] = 1
            self.PC += 1
            msg = "SEI → Kesmeler devre dışı"
            cycles = 2
        elif op == 0x0F:  # CLI (Clear Interrupt Mask)
            self.flags['I'] = 0
            self.PC += 1
            msg = "CLI → Kesmeler etkin"
            cycles = 2
        elif op == 0x3B:  # RTI (Return from Interrupt)
            # CCR'ı stack'ten geri yükle
            ccr = self.memory[self.SP]
            self.flags['I'] = (ccr >> 4) & 1
            self.flags['N'] = (ccr >> 3) & 1
            self.flags['Z'] = (ccr >> 2) & 1
            self.flags['V'] = (ccr >> 1) & 1
            self.flags['C'] = ccr & 1
            self.SP = (self.SP + 1) & 0xFFFF
            
            # PC'yi stack'ten geri yükle
            lo = self.memory[self.SP]
            hi = self.memory[self.SP+1]
            self.PC = (hi << 8) | lo
            self.SP = (self.SP + 2) & 0xFFFF
            msg = "RTI → Kesmeden döndü"
            cycles = 6
        else:
            self.PC += 1
            msg = f"Bilinmeyen opcode: {to_hex(op)}"
            cycles = 1
        
        self.last_effect = msg
        self.cycle_count += cycles
        self.last_execution_time = time.perf_counter() - start_time
        self.stats[msg.split()[0]] += 1
        return msg

class AssemblerUI:
    def __init__(self, assembler: Assembler6800, simulator: Simulator6800):
        self.assembler = assembler
        self.simulator = simulator
        self.root = tk.Tk()
        self.root.title("Motorola 6800 Assembler & Gelişmiş Simülatör")
        self.root.geometry("1400x820")
        self.breakpoints = set()
        self.line_to_pc = {}  # Satır no -> PC adresi
        self.pc_to_line = {}  # PC -> Satır no
        self.cpu_speed = 1.0  # Varsayılan CPU hızı (1.0 = gerçek zamanlı)
        self.conditional_breakpoints = {}  # Koşullu breakpoint'ler
        self.performance_data = []
        self.memory_view_start = 0x8000
        self.memory_view_end = 0x80FF

        # Ana çerçeveler
        self.top_frame = tk.Frame(self.root)
        self.top_frame.pack(fill="x", padx=10, pady=5)
        
        self.mid_frame = tk.Frame(self.root)
        self.mid_frame.pack(fill="x", padx=10, pady=5)
        
        self.bottom_frame = tk.Frame(self.root)
        self.bottom_frame.pack(fill="both", expand=True, padx=10, pady=5)

        # Kod giriş alanı
        self.input_label = tk.Label(self.top_frame, text="Assembly Kodunuzu Girin veya Yükleyin:", font=("Arial", 11, "bold"))
        self.input_label.pack(anchor="w")
        
        input_frame = tk.Frame(self.top_frame)
        input_frame.pack(fill="x")
        
        self.input_box = scrolledtext.ScrolledText(input_frame, height=12, width=80, font=("Consolas", 11))
        self.input_box.pack(side="left", fill="both", expand=True, padx=(0, 5))
        self.input_box.bind("<Button-1>", self.highlight_breakpoint_lines)
        
        # Hız kontrolü ve istatistik paneli
        control_frame = tk.Frame(input_frame)
        control_frame.pack(side="right", fill="y")
        
        tk.Label(control_frame, text="CPU Hızı:", font=("Arial", 10)).pack(anchor="w", pady=(0, 5))
        self.speed_slider = tk.Scale(control_frame, from_=0.1, to=10, resolution=0.1, orient="horizontal", 
                                length=200, command=self.set_cpu_speed)
        self.speed_slider.set(1.0)
        self.speed_slider.pack(anchor="w", fill="x")
        
        tk.Label(control_frame, text="İstatistikler:", font=("Arial", 10, "bold")).pack(anchor="w", pady=(10, 5))
        self.stats_text = scrolledtext.ScrolledText(control_frame, height=8, width=30, font=("Consolas", 9))
        self.stats_text.pack(fill="both", expand=True)
        self.stats_text.config(state="disabled")
        
        # Butonlar
        self.button_frame = tk.Frame(self.top_frame)
        self.button_frame.pack(fill="x", pady=5)
        
        buttons = [
            ("Dosya Aç", self.open_file),
            ("Dosyaya Kaydet", self.save_file),
            ("Derle", self.assemble_code, {"bg": "#36c", "fg": "white", "font": ("Arial", 10, "bold")}),
            ("Temizle", self.clear_all),
            ("Örnek Kod Yükle", self.load_example),
            ("Simülatörü Sıfırla", self.reset_sim),
            ("Breakpoint Ekle/Sil", self.toggle_breakpoint),
            ("IRQ Tetikle", self.trigger_irq),
            ("NMI Tetikle", self.trigger_nmi),
            ("İstatistikleri Gör", self.show_stats)
        ]
        
        for i, (text, command, *opts) in enumerate(buttons):
            opts = opts[0] if opts else {}
            btn = tk.Button(self.button_frame, text=text, command=command, **opts)
            btn.grid(row=0, column=i, padx=3)

        # Eşleştirme tablosu
        self.out_label = tk.Label(self.mid_frame, text="Satır-Satır Eşleştirme Tablosu", font=("Arial", 11, "bold"))
        self.out_label.pack(anchor="w")
        self.output_box = scrolledtext.ScrolledText(self.mid_frame, height=8, width=130, font=("Consolas", 11), state="disabled")
        self.output_box.pack(fill="x")

        # Simülasyon panelleri
        sim_panels = tk.PanedWindow(self.bottom_frame, orient="horizontal", sashwidth=4)
        sim_panels.pack(fill="both", expand=True)
        
        # Bellek görüntüleyici
        mem_frame = tk.LabelFrame(sim_panels, text="Bellek Görüntüleyici", padx=5, pady=5)
        self.mem_view = scrolledtext.ScrolledText(mem_frame, height=15, width=50, font=("Consolas", 10))
        self.mem_view.pack(fill="both", expand=True)
        
        mem_control = tk.Frame(mem_frame)
        mem_control.pack(fill="x", pady=(5, 0))
        
        tk.Label(mem_control, text="Başlangıç:").pack(side="left")
        self.mem_start = tk.Entry(mem_control, width=6)
        self.mem_start.insert(0, "8000")
        self.mem_start.pack(side="left", padx=(0, 10))
        
        tk.Label(mem_control, text="Bitiş:").pack(side="left")
        self.mem_end = tk.Entry(mem_control, width=6)
        self.mem_end.insert(0, "80FF")
        self.mem_end.pack(side="left", padx=(0, 10))
        
        tk.Button(mem_control, text="Göster", command=self.update_memory_view).pack(side="left")
        
        sim_panels.add(mem_frame)
        
        # Simülasyon logları
        log_frame = tk.LabelFrame(sim_panels, text="Simülasyon Logları", padx=5, pady=5)
        self.sim_log = scrolledtext.ScrolledText(log_frame, height=15, width=50, font=("Consolas", 9), bg="#fff9c4")
        self.sim_log.pack(fill="both", expand=True)
        sim_panels.add(log_frame)
        
        # Kayıtlar ve stack
        right_frame = tk.Frame(sim_panels)
        sim_panels.add(right_frame)
        
        # Kayıtlar ve bayraklar
        reg_frame = tk.LabelFrame(right_frame, text="Kayıtlar ve Bayraklar", padx=5, pady=5)
        reg_frame.pack(fill="x", padx=(0, 0), pady=(0, 5))
        
        self.reg_view = tk.Label(reg_frame, text="", font=("Consolas", 12), justify="left", fg="darkblue")
        self.reg_view.pack(anchor="w")
        
        self.flag_view = tk.Label(reg_frame, text="", font=("Consolas", 11), justify="left", fg="brown")
        self.flag_view.pack(anchor="w")
        
        # Stack görüntüleyici
        stack_frame = tk.LabelFrame(right_frame, text="Stack Viewer", padx=5, pady=5)
        stack_frame.pack(fill="both", expand=True)
        
        self.stack_view = scrolledtext.ScrolledText(stack_frame, height=8, width=22, font=("Consolas", 9), bg="#f0f8ff")
        self.stack_view.pack(fill="both", expand=True)
        
        # Kontrol paneli
        control_frame = tk.LabelFrame(right_frame, text="Simülasyon Kontrolleri", padx=5, pady=5)
        control_frame.pack(fill="x", pady=(5, 0))
        
        self.sim_btn = tk.Button(control_frame, text="Adım Adım", command=self.sim_step, bg="#399", fg="white",
                                font=("Arial", 10, "bold"), width=14)
        self.sim_btn.pack(pady=2)
        
        self.run_all_btn = tk.Button(control_frame, text="Tümünü Çalıştır", command=self.run_all_steps,
                                    bg="#b33", fg="white", font=("Arial", 10, "bold"), width=16)
        self.run_all_btn.pack(pady=2)
        
        self.status_counter = tk.Label(control_frame, text="Adım: 0  Döngü: 0", font=("Arial", 10), fg="blue")
        self.status_counter.pack(anchor="w", pady=(5, 0))
        
        self.speed_label = tk.Label(control_frame, text="Hız: 1.0x", font=("Arial", 9))
        self.speed_label.pack(anchor="w")
        
        self.sim_status = tk.Label(control_frame, text="", font=("Arial", 10, "bold"), fg="green")
        self.sim_status.pack(anchor="w", pady=(3, 0))
        
        # Performans grafiği
        self.fig, self.ax = plt.subplots(figsize=(5, 2))
        self.canvas = FigureCanvasTkAgg(self.fig, master=right_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, pady=(5, 0))
        self.ax.set_title("CPU Kullanımı")
        self.ax.set_ylim(0, 100)
        self.ax.set_xlim(0, 10)
        self.line, = self.ax.plot([], [], 'r-')
        self.graph_data = []
        
        # Kayıt düzenleyici
        self.reg_edit_frame = tk.Frame(reg_frame)
        self.reg_edit_frame.pack(fill="x", pady=(5, 0))
        
        tk.Label(self.reg_edit_frame, text="A:").grid(row=0, column=0)
        self.reg_a = tk.Entry(self.reg_edit_frame, width=4)
        self.reg_a.grid(row=0, column=1, padx=(0, 5))
        
        tk.Label(self.reg_edit_frame, text="B:").grid(row=0, column=2)
        self.reg_b = tk.Entry(self.reg_edit_frame, width=4)
        self.reg_b.grid(row=0, column=3, padx=(0, 5))
        
        tk.Label(self.reg_edit_frame, text="X:").grid(row=0, column=4)
        self.reg_x = tk.Entry(self.reg_edit_frame, width=6)
        self.reg_x.grid(row=0, column=5, padx=(0, 5))
        
        tk.Button(self.reg_edit_frame, text="Uygula", command=self.apply_reg_edits).grid(row=0, column=6)
        
        self.last_code = None
        self.start_addr = 0x8000
        self.root.after(100, self.update_performance_graph)

    def update_performance_graph(self):
        if len(self.performance_data) > 50:
            self.performance_data.pop(0)
        
        # CPU kullanımını hesapla (1ms'den fazla süren işlemler %100 kabul edilir)
        usage = min(100, self.simulator.last_execution_time * 1000 * 100)
        self.performance_data.append(usage)
        
        self.line.set_data(range(len(self.performance_data)), self.performance_data)
        self.ax.set_xlim(0, max(10, len(self.performance_data)))
        self.ax.set_ylim(0, max(100, max(self.performance_data or [0]) * 1.1))
        self.canvas.draw()
        self.root.after(100, self.update_performance_graph)

    def apply_reg_edits(self):
        try:
            if self.reg_a.get():
                self.simulator.A = parse_number(self.reg_a.get()) & 0xFF
            if self.reg_b.get():
                self.simulator.B = parse_number(self.reg_b.get()) & 0xFF
            if self.reg_x.get():
                self.simulator.X = parse_number(self.reg_x.get()) & 0xFFFF
            self.update_sim_display("Kayıtlar güncellendi")
        except ValueError as e:
            messagebox.showerror("Hata", str(e))

    def set_cpu_speed(self, speed):
        self.cpu_speed = float(speed)
        self.speed_label.config(text=f"Hız: {self.cpu_speed:.1f}x")

    def trigger_irq(self):
        self.simulator.irq_pending = True
        self.sim_status.config(text="IRQ sinyali gönderildi", fg="orange")

    def trigger_nmi(self):
        self.simulator.nmi_pending = True
        self.sim_status.config(text="NMI sinyali gönderildi", fg="red")

    def show_stats(self):
        stats = self.simulator.stats
        total = sum(stats.values())
        
        stats_text = "İSTATİSTİKLER:\n"
        stats_text += f"Toplam Adım: {self.simulator.step_count}\n"
        stats_text += f"Toplam Döngü: {self.simulator.cycle_count}\n"
        stats_text += f"Çalışma Süresi: {time.time() - self.simulator.start_time:.2f}s\n"
        stats_text += "\nKomut Dağılımı:\n"
        
        for inst, count in sorted(stats.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / total) * 100 if total > 0 else 0
            stats_text += f"{inst:<8}: {count:>4} ({percentage:.1f}%)\n"
        
        self.stats_text.config(state="normal")
        self.stats_text.delete(1.0, tk.END)
        self.stats_text.insert(tk.END, stats_text)
        self.stats_text.config(state="disabled")

    def update_memory_view(self):
        try:
            self.memory_view_start = parse_number(self.mem_start.get())
            self.memory_view_end = parse_number(self.mem_end.get())
            
            if self.memory_view_end <= self.memory_view_start:
                raise ValueError("Bitiş adresi başlangıçtan küçük olamaz")
            
        except ValueError as e:
            messagebox.showerror("Hata", str(e))
            return
        
        self.mem_view.delete(1.0, tk.END)
        addr = self.memory_view_start
        while addr <= self.memory_view_end:
            # Adres başlığı
            self.mem_view.insert(tk.END, f"{to_hex(addr, 4)}: ")
            
            # Hex değerler
            hex_vals = []
            ascii_vals = []
            for i in range(16):
                if addr + i > self.memory_view_end:
                    break
                val = self.simulator.memory[addr + i]
                hex_vals.append(to_hex(val))
                
                # ASCII karakter (yazdırılabilir karakterler için)
                if 32 <= val <= 126:
                    ascii_vals.append(chr(val))
                else:
                    ascii_vals.append('.')
            
            # Hex kısmını ekle
            self.mem_view.insert(tk.END, ' '.join(hex_vals))
            
            # ASCII kısmını ekle
            self.mem_view.insert(tk.END, '  |' + ''.join(ascii_vals) + '|\n')
            
            addr += 16

    def highlight_breakpoint_lines(self, event=None):
        self.input_box.tag_configure('breakpoint', background='#ffcccc')
        for line in self.breakpoints:
            self.input_box.tag_add('breakpoint', f'{line}.0', f'{line}.end')

    def highlight_execution_line(self):
        self.input_box.tag_remove('currentline', '1.0', tk.END)
        self.input_box.tag_remove('breakpoint', '1.0', tk.END)
        self.input_box.tag_remove('both', '1.0', tk.END)
        pc = self.simulator.PC
        line = self.pc_to_line.get(pc, None)
        for br in self.breakpoints:
            self.input_box.tag_add('breakpoint', f'{br}.0', f'{br}.end')
            self.input_box.tag_config('breakpoint', background='#ffcccc')
        if line:
            line_str = str(line)
            index = f"{line}.0"
            if line_str in self.breakpoints:
                self.input_box.tag_add('both', index, f"{line}.end")
                self.input_box.tag_config('both', background='#ffd580')
            else:
                self.input_box.tag_add('currentline', index, f"{line}.end")
                self.input_box.tag_config('currentline', background='#aaffaa')
            self.input_box.see(index)

    def toggle_breakpoint(self):
        line = self.input_box.index(tk.INSERT).split('.')[0]
        if line in self.breakpoints:
            self.breakpoints.remove(line)
            self.input_box.tag_remove('breakpoint', f'{line}.0', f'{line}.end')
        else:
            # Koşullu breakpoint dialogu
            condition = tk.simpledialog.askstring("Koşullu Breakpoint", 
                                                 "Breakpoint koşulu girin (örn: A==5):",
                                                 parent=self.root)
            if condition is not None:  # Kullanıcı Cancel'a basmadıysa
                self.breakpoints.add(line)
                if condition.strip():
                    self.conditional_breakpoints[line] = condition
                self.input_box.tag_add('breakpoint', f'{line}.0', f'{line}.end')
                self.input_box.tag_config('breakpoint', background='#ffcccc')

    def run(self):
        self.root.mainloop()

    def open_file(self):
        fname = filedialog.askopenfilename(filetypes=[("Assembly Files", "*.asm *.txt"), ("All Files", "*.*")])
        if fname:
            with open(fname, 'r', encoding='utf-8') as f:
                content = f.read()
            self.input_box.delete(1.0, tk.END)
            self.input_box.insert(tk.END, content)

    def save_file(self):
        fname = filedialog.asksaveasfilename(filetypes=[("Assembly Files", "*.asm *.txt"), ("All Files", "*.*")], defaultextension=".asm")
        if fname:
            with open(fname, 'w', encoding='utf-8') as f:
                f.write(self.input_box.get(1.0, tk.END))
            messagebox.showinfo("Başarılı", "Kod dosyaya kaydedildi.")

    def assemble_code(self):
        code = self.input_box.get(1.0, tk.END)
        try:
            machine_code, table, origin = self.assembler.assemble(code)
            self.pc_to_line = self.assembler.pc_to_line.copy()
            self.line_to_pc = {}
            for pc, ln in self.pc_to_line.items():
                self.line_to_pc[str(ln)] = pc
        except Exception as e:
            messagebox.showerror("Derleme Hatası", str(e))
            return
        self.output_box.config(state="normal")
        self.output_box.delete(1.0, tk.END)
        self.output_box.insert(tk.END, f"{'Assembly'.ljust(35)} {'Adres'.ljust(7)} Makine Kodu\n")
        self.output_box.insert(tk.END, "-"*80+"\n")
        for asm, addr, obj in table:
            line = asm.ljust(35)[:35] + " " + addr.ljust(7) + " " + obj
            self.output_box.insert(tk.END, line + "\n")
        self.output_box.config(state="disabled")
        self.simulator.reset()
        self.simulator.load_code(machine_code, origin)
        self.last_code = machine_code
        self.start_addr = origin
        self.update_sim_display(msg="Kod Belleğe Yüklendi, Simüle edebilirsiniz.")
        self.update_memory_view()

    def clear_all(self):
        self.input_box.delete(1.0, tk.END)
        self.output_box.config(state="normal")
        self.output_box.delete(1.0, tk.END)
        self.output_box.config(state="disabled")
        self.simulator.reset()
        self.mem_view.delete(1.0, tk.END)
        self.reg_view.config(text="")
        self.flag_view.config(text="")
        self.sim_status.config(text="")
        self.sim_log.delete(1.0, tk.END)
        self.last_code = None
        self.breakpoints = set()
        self.input_box.tag_remove('breakpoint', '1.0', tk.END)
        self.input_box.tag_remove('currentline', '1.0', tk.END)
        self.stats_text.config(state="normal")
        self.stats_text.delete(1.0, tk.END)
        self.stats_text.config(state="disabled")

    def load_example(self):
        example = """; Motorola 6800 döngü + işlemler
ORG $8000
        LDAA #$05
        LDAB #$01
TOPLA:  ADDA #$03
        INCB
        CMPB #$05
        BNE TOPLA
        STAA $20
        JMP $8000
END
"""
        self.input_box.delete(1.0, tk.END)
        self.input_box.insert(tk.END, example)

    def reset_sim(self):
        if hasattr(self, 'last_code') and self.last_code:
            self.simulator.reset()
            self.simulator.load_code(self.last_code, self.start_addr)
            self.update_sim_display(msg="Simülatör Sıfırlandı.")
            self.update_memory_view()
        else:
            self.simulator.reset()
            self.update_sim_display(msg="")
        self.status_counter.config(text=f"Adım: 0  Döngü: 0")

    def sim_step(self):
        line = self.pc_to_line.get(self.simulator.PC, None)
        if line and str(line) in self.breakpoints:
            # Koşullu breakpoint kontrolü
            condition = self.conditional_breakpoints.get(str(line), "")
            if condition:
                try:
                    # Güvenli koşul değerlendirmesi
                    if not eval(condition, {}, {
                        'A': self.simulator.A,
                        'B': self.simulator.B,
                        'X': self.simulator.X,
                        'PC': self.simulator.PC,
                        'Z': self.simulator.flags['Z'],
                        'C': self.simulator.flags['C'],
                        'N': self.simulator.flags['N'],
                        'V': self.simulator.flags['V']
                    }):
                        # Koşul sağlanmıyorsa breakpoint'i atla
                        pass
                    else:
                        self.sim_status.config(text=f"Breakpoint: Satır {line} (Devam için tekrar Adım Adım)")
                        return
                except Exception as e:
                    self.sim_status.config(text=f"Breakpoint hatası: {str(e)}")
                    return
            else:
                self.sim_status.config(text=f"Breakpoint: Satır {line} (Devam için tekrar Adım Adım)")
                return
        
        msg = self.simulator.step()
        self.status_counter.config(text=f"Adım: {self.simulator.step_count}  Döngü: {self.simulator.cycle_count}")
        self.update_sim_display(msg)
        
        # Hız simülasyonu
        if self.cpu_speed > 0 and self.simulator.last_execution_time < 1/self.cpu_speed:
            delay = (1/self.cpu_speed - self.simulator.last_execution_time) * 1000
            self.root.after(int(delay))

    def update_sim_display(self, msg=""):
        pc = self.simulator.PC
        self.update_memory_view()
        
        regtxt = f"A={to_hex(self.simulator.A)}  B={to_hex(self.simulator.B)}  X={to_hex(self.simulator.X,4)}"
        regtxt += f"\nPC={to_hex(self.simulator.PC,4)}  SP={to_hex(self.simulator.SP,4)}"
        self.reg_view.config(text=regtxt)
        
        self.reg_a.delete(0, tk.END)
        self.reg_a.insert(0, to_hex(self.simulator.A))
        self.reg_b.delete(0, tk.END)
        self.reg_b.insert(0, to_hex(self.simulator.B))
        self.reg_x.delete(0, tk.END)
        self.reg_x.insert(0, to_hex(self.simulator.X,4))
        
        flagtxt = " ".join(f"{k}={self.simulator.flags[k]}" for k in "NZVC")
        flagtxt += f"  I={self.simulator.flags['I']}"
        self.flag_view.config(text="Flags: "+flagtxt)
        
        if msg:
            self.sim_status.config(text=msg)
            self.sim_log.insert(tk.END, msg + "\n")
            self.sim_log.see(tk.END)
        
        self.highlight_execution_line()
        self.update_stack_view()
        
    def update_stack_view(self):
        sp = self.simulator.SP
        stack_content = ""
        for i in range(16):
            addr = (sp + i) & 0xFFFF
            stack_content += f"{to_hex(addr,4)}: {to_hex(self.simulator.memory[addr])}\n"
        self.stack_view.delete(1.0, tk.END)
        self.stack_view.insert(tk.END, stack_content)

    def run_all_steps(self):
        count = 0
        pc_history = {}
        start_time = time.time()
        
        while True:
            current_pc = self.simulator.PC
            line = self.pc_to_line.get(current_pc, None)
            if line and str(line) in self.breakpoints:
                # Koşullu breakpoint kontrolü
                condition = self.conditional_breakpoints.get(str(line), "")
                if condition:
                    try:
                        if not eval(condition, {}, {
                            'A': self.simulator.A,
                            'B': self.simulator.B,
                            'X': self.simulator.X,
                            'PC': self.simulator.PC,
                            'Z': self.simulator.flags['Z'],
                            'C': self.simulator.flags['C'],
                            'N': self.simulator.flags['N'],
                            'V': self.simulator.flags['V']
                        }):
                            # Koşul sağlanmıyorsa breakpoint'i atla
                            pass
                        else:
                            self.sim_status.config(text=f"Breakpoint: Satır {line} (Devam için tekrar Tümünü Çalıştır)")
                            break
                    except:
                        pass
                else:
                    self.sim_status.config(text=f"Breakpoint: Satır {line} (Devam için tekrar Tümünü Çalıştır)")
                    break
            
            pc_history[current_pc] = pc_history.get(current_pc, 0) + 1
            if pc_history[current_pc] > 100:
                self.update_sim_display(f"Sonsuz döngü tespit edildi! (PC = {to_hex(current_pc, 4)})")
                break
            
            msg = self.simulator.step()
            self.status_counter.config(text=f"Adım: {self.simulator.step_count}  Döngü: {self.simulator.cycle_count}")
            self.update_sim_display(msg)
            
            count += 1
            if "Bilinmeyen opcode" in msg or count > 10000:
                break
            
            # Hız simülasyonu
            if self.cpu_speed > 0 and self.simulator.last_execution_time < 1/self.cpu_speed:
                delay = (1/self.cpu_speed - self.simulator.last_execution_time) * 1000
                self.root.update()
                time.sleep(delay / 1000)
            else:
                self.root.update()
        
        elapsed = time.time() - start_time
        self.sim_status.config(text=f"Simülasyon tamamlandı. {count} adım, {elapsed:.2f}s")

if __name__ == "__main__":
    assembler = Assembler6800()
    simulator = Simulator6800()
    app = AssemblerUI(assembler, simulator)
    app.run()