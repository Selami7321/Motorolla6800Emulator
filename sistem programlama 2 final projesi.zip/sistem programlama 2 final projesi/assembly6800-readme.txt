# Motorola 6800 Assembler & Simülatör Kullanıcı Kılavuzu

## 1. Proje Hakkında
Bu araç, Motorola 6800 Assembly kodlarını makine koduna çevirir, etiketleri çözümler ve satır-satır eşleştirme tablosu oluşturur. Ayrıca simülasyon modunda kodunuzu adım adım çalıştırabilir, bellek ve register’ların anlık durumunu gözlemleyebilirsiniz.

## 2. Kurulum ve Çalıştırma
1. Python 3.x yüklü olmalı.
2. Gerekli dosyaları bir klasöre çıkarın.
3. Terminalden/komut isteminden `python assembly6800.py` çalıştırın.

## 3. Temel Özellikler
- **Kod Girişi:** Kodunuzu arayüze yazın veya dosyadan yükleyin.
- **Derleme:** “Derle” butonuna basarak assembly kodunu makine koduna çevirin.
- **Satır Eşleme Tablosu:** Her assembly satırı için karşılık gelen adres ve makine kodunu görün.
- **Simülatör:** 
  - Adım Adım (“Adım Adım” butonu)
  - Tümünü Çalıştır (“Tümünü Çalıştır” butonu)
  - Breakpoint ekleyip satırda durdurma
  - Bellek ve register’ları anlık takip etme
- **Bellek/Stack Viewer:** Simülasyon sırasında hafıza ve stack içeriğini görebilirsiniz.
- **Örnek Kod:** “Örnek Kod Yükle” butonu ile test kodu yükleyebilirsiniz.

## 4. Kullanım Akışı
1. Kodunuzu girin/yükleyin.
2. Derleyin.
3. Eşleme tablosu ve hata varsa mesajları inceleyin.
4. Simülasyon modunda adım adım çalıştırın, breakpoint ayarlayın, belleği ve register’ları takip edin.

## 5. Sık Karşılaşılan Hatalar
- **Hatalı komut:** Geçersiz assembly komutu yazarsanız kırmızı olarak işaretlenir.
- **Label bulunamıyor:** Tanımlanmamış label’lar için hata alırsınız.
- **Offset hatası:** Branch komutlarında offset aralığı dışında değer verirseniz uyarı çıkar.

## 6. Kısa Kod Örneği
```assembly
ORG $8000
LDAA #$10
LDAB #$05
TOPLA: ADDA #$03
       DECB
       BNE TOPLA
       STAA $20
       JMP $8000
END
